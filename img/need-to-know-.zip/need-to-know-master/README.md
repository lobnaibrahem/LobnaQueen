# need-to-know
my first website i made with only html and css in a gdg(google devolopers group) 6 of october city project's contest
if thare is any mistakes please notice me 
i'm a beginner web designer and inshallah developer 
